#!/system/bin/sh
# Cloud Configuration
# 酷安@阿巴酱(Petit Abba)
# 所有路径都已验证(√)
#sxkiss修改库-未更改任何核心代码-只改了规则和云更新地址-欢迎反馈提交-admin@sxkiss.com
