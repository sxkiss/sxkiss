#sxkiss

# sxkiss

id=Third_Party_Redirect

name=第三方应用下载目录重定向

version=v5.2.3-[云端版]修改版

versionCode=20210620

author=落葉淒涼(高雄佬) & 阿巴酱

description=请等待刷新..

VersionNumber=20210620

下载最新 
<a href="https://github.com/sxkiss/sxkiss/blob/master/Third_Party_Redirect/Third_Party_Redirect.zip?raw=true/">下载最新模块</a>
